package com.edu;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Teacher {
	 
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 private Integer teacherId;
	 
	 
	 private String teacherName;
	 
	 
	 private Float teacherSalary; 
     
	 
	 //relation with subject
	
	 @OneToMany(mappedBy = "teacher")
	 private Set<Subject> subject = new HashSet<Subject>();
	 
	 
	public Set<Subject> getSubject() {
		return subject;
	}

	public void setSubject(Set<Subject> subject) {
		this.subject = subject;
	}

	public Integer getTeacherId() {
		return teacherId;
	}

	public void setTeacherId(Integer teacherId) {
		this.teacherId = teacherId;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public Float getTeacherSalary() {
		return teacherSalary;
	}

	public void setTeacherSalary(Float teacherSalary) {
		this.teacherSalary = teacherSalary;
	}
	
}

package com.hcl.gl.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Movie {
    private String title;
    private int year;

    public Movie(String title, int year) {
        this.title = title;
        this.year = year;
    }

    public String getTitle() {
        return title;
    }

    public int getYear() {
        return year;
    }
}

class MovieDao {
    private List<Movie> movieList;

    public MovieDao() {
        movieList = new ArrayList<>();
    }

    public void addMovie() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter movie title: ");
        String title = sc.nextLine();

        System.out.print("Enter movie year: ");
        int year = sc.nextInt();

        Movie movie = new Movie(title, year);
        movieList.add(movie);
        System.out.println("Movie added successfully!");
    }

    public void updateMovie() {
        // Update movie implementation
    }

    public void deleteMovie() {
        // Delete movie implementation
    }

    public void searchMovie() {
        // Search movie implementation
    }

    public void assignMovieToCategory() {
        // Assign movie to category implementation
    }

    public void viewAllMovies() {
        if (movieList.isEmpty()) {
            System.out.println("No movies available in the library.");
        } else {
            System.out.println("Movie Library:");
            for (Movie movie : movieList) {
                System.out.println("Title: " + movie.getTitle() + ", Year: " + movie.getYear());
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        int choice;
        Scanner sc = new Scanner(System.in);

        MovieDao movieDao = new MovieDao();

        do {
            System.out.println("************Movie Management System Menu************");
            System.out.println("1. Adding a Movie in the Library");
            System.out.println("2. Updating a Movie in the Library");
            System.out.println("3. Deleting a Movie from the Library");
            System.out.println("4. Searching a Movie in the Library");
            System.out.println("5. Assign movie to a category");
            System.out.println("6. View All movies");
            System.out.println("0. Exit the application");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Add");
                    movieDao.addMovie();
                    break;

                case 2:
                    System.out.println("Update");
                    movieDao.updateMovie();
                    break;

                case 3:
                    System.out.println("Delete");
                    movieDao.deleteMovie();
                    break;

                case 4:
                    System.out.println("Search");
                    movieDao.searchMovie();
                    break;

                case 5:
                    System.out.println("Assign movie to a category");
                    movieDao.assignMovieToCategory();
                    break;

                case 6:
                    System.out.println("View All movies");
                    movieDao.viewAllMovies();
                    break;

                case 0:
                    System.out.println("Exit");
                    break;

                default:
                    System.out.println("Please try again");
                    break;
            }

        } while (choice != 0);

        sc.close();
    }
}
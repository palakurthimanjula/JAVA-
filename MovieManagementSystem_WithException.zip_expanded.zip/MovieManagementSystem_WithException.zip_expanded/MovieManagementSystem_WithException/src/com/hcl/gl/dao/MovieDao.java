package com.hcl.gl.dao;

import java.util.ArrayList;

import java.util.List;
import java.util.Scanner;

import com.hcl.gl.exception.NegativeException;
import com.hcl.gl.pojo.Movie;
  public class MovieDao {
	  private Scanner sc = new Scanner(System.in);
	    private List<Movie> movies = new ArrayList<>();
	    public static void main(String[] args) {
			 MovieDao movieDao = new MovieDao();
		
			 movieDao.addMovie();
			 movieDao.updateMovie();
			 movieDao.searchMovie();
			 movieDao.assigneeMovie();
			 movieDao.viewAllMovies();
	    }
    public void addMovie() {
        Movie movie = new Movie();
        System.out.println("Enter movieId: ");
        movie.setMovieId(sc.nextInt());
        System.out.println("Enter movie name: ");
        movie.setMovieName(sc.next());
        System.out.println("Enter movie text: ");
        movie.setMovieText(sc.next());
        System.out.println("Enter movie category: ");
        movie.setMovieCategory(sc.next());
        movies.add(movie);
        System.out.println("Movie added");
    }

    public void updateMovie() throws NegativeException {
        int flag = 0;
        System.out.println("Enter the movie name to be updated: ");
        String movieName = sc.next();
        for (Movie movie : movies) {
            if (movieName.equals(movie.getMovieName())) {
                System.out.println("Enter the updated movie name: ");
                String updatedMovie = sc.next();
                movie.setMovieName(updatedMovie);
                System.out.println("Movie name updated");
                flag = 1;
                break;
            }
        }
        if (flag == 0) {
            try {
                throw new NegativeException("Movie does not exist");
            } catch (NegativeException ne) {
                System.out.println("Please try again!");
        }
 }
 }

    public void searchMovie() {
        int flag = 0;
        System.out.println("Enter the movie name to be searched: ");
        String movieName = sc.next();
        for (Movie movie : movies) {
            if (movieName.equals(movie.getMovieName())) {
                System.out.println("Movie name searched: " + movie.getMovieName() + " " + movie.getMovieId());
                flag = 1;
                break;
     }
  }
        if (flag == 0) {
            try {
                throw new NegativeException("Movie could not be searched");
 } catch (NegativeException ne) {
                System.out.println("Please try again!");
  }
 }
   }

    public void assigneeMovie() {
        int flag = 0;
        System.out.println("Enter the movie name to be assigned to a user: ");
        String movieName = sc.next();
        for (Movie movie : movies) {
            if (movieName.equals(movie.getMovieName())) {
                System.out.println("Enter the name of the assignee user: ");
                movie.setAssignedTo(sc.next());
                flag = 1;
                break;
     }
   }
        if (flag == 0) {
            System.out.println("Movie does not exist");
 }
}

    public void viewAllMovies() {
        for (Movie movie : movies) {
            System.out.println(movie.getMovieId() + " " + movie.getMovieName() + " " + movie.getAssignedTo());
            
            
         }
            	
       }
	} 
    

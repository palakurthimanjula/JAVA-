package com.hcl.gl.exception;

public class NegativeException extends RuntimeException 
{
    public NegativeException(String msg)   //PARAMETERIZED CONSTRUCTOR
    {
    	System.out.println("Invalid Input: "+msg);
    }
}


//CREATE A NEW PACKAGE

//Create a class NegativeException

//extends RuntimeException

//Paramterized Constructor
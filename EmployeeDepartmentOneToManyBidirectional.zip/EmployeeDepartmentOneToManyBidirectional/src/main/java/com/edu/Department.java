package com.edu;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity

public class Department {

     @Id
	private int deptartmentid; 
     @Column(length=50, nullable = false, unique = true)
	private String departmentname;
     
     @Column(length=50, nullable = false, unique = true)
	private String departmentlocation;

     @OneToMany(cascade = CascadeType.ALL)
     @JoinColumn(name="deptartmentid")
    List <Employee> employee = new ArrayList<Employee>();
     
     
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Department( String departmentname, String departmentlocation) {
		super();
	
		this.departmentname = departmentname;
		this.departmentlocation = departmentlocation;
	}

	public int getDeptartmentid() {
		return deptartmentid;
	}

	public void setDeptartmentid(int deptartmentid) {
		this.deptartmentid = deptartmentid;
	}

	public String getDepartmentname() {
		return departmentname;
	}

	public void setDepartmentname(String departmentname) {
		this.departmentname = departmentname;
	}

	public String getDepartmentlocation() {
		return departmentlocation;
	}

	public void setDepartmentlocation(String departmentlocation) {
		this.departmentlocation = departmentlocation;
	}

	
	
	public List<Employee> getEmployee() {
		return employee;
	}

	public void setEmployee(List<Employee> employee) {
		this.employee = employee;
	}

	@Override
	public String toString() {
		return "Department [deptartmentid=" + deptartmentid + ", departmentname=" + departmentname
				+ ", departmentlocation=" + departmentlocation + "]";
	}
     
     
	
}

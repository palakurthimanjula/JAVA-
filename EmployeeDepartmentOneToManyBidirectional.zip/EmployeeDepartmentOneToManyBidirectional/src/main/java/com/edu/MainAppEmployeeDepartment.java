package com.edu;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainAppEmployeeDepartment {

	public static void main(String[] args) {
		Configuration configuration=new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		configuration.addAnnotatedClass(Department.class);
		configuration.addAnnotatedClass(Employee.class);
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		//create department object
		Department department = new Department();
		department.setDepartmentname("Sales");
        department.setDepartmentlocation("Bangalore");
		//create employee object
		Employee emp1 = new Employee("Nina",22);
		Employee emp2 = new Employee("Tony",34);
		ArrayList<Employee>emplist=new ArrayList<Employee>();
		emplist.add(emp1);
		emplist.add(emp2);
		department.setEmployee(emplist);
				
		session.save(department);
		transaction.commit();
		session.close();

	}

}

package com.edu;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.ManyToAny;

@Entity
public class Employee {

	@Id //primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) //auto incrememt
	private int employeeid;
	
	@Column(length=50, nullable = false)
	private String employeename;
	
	private int employeeage;

	@ManyToOne
    @JoinColumn(name="deptartmentid")
	Department department;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee( String employeename, int employeeage) {
		super();
		
		this.employeename = employeename;
		this.employeeage = employeeage;
	}

	@Override
	public String toString() {
		return "Employee [employeeid=" + employeeid + ", employeename=" + employeename + ", employeeage=" + employeeage
				+ "]";
	}

	public int getEmployeeid() {
		return employeeid;
	}

	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}

	public String getEmployeename() {
		return employeename;
	}

	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}

	public int getEmployeeage() {
		return employeeage;
	}

	public void setEmployeeage(int employeeage) {
		this.employeeage = employeeage;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}
	
	
}

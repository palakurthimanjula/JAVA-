package com.map.onetoone.utility;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.service.ServiceRegistry;

import com.map.onetoone.entity.Instructor;
import com.map.onetoone.entity.InstructorDetail;



public class JavaConfig {
	
	private static SessionFactory sessionFactory=null;
	
	
	public static SessionFactory getSessionFactory()
	{
		if(sessionFactory==null)
		{
			Configuration configuration=new Configuration();
			Properties properties=new Properties();
			
			
			properties.setProperty(Environment.URL, "jdbc:mysql://localhost:3306/hibernate_mapping_db");
			properties.setProperty(Environment.USER, "root");
			properties.setProperty(Environment.PASS, "root");
			properties.setProperty(Environment.DRIVER, "com.mysql.cj.jdbc.Driver");
			properties.setProperty(Environment.SHOW_SQL, "true");
			properties.setProperty(Environment.HBM2DDL_AUTO, "update");
			
			configuration.setProperties(properties);
			configuration.addAnnotatedClass(Instructor.class);
			configuration.addAnnotatedClass(InstructorDetail.class);
			ServiceRegistry serviceRegistry=new StandardServiceRegistryBuilder()
					.applySettings(configuration.getProperties()).build();
			
			sessionFactory=configuration.buildSessionFactory(serviceRegistry);
			
			 return sessionFactory;
		}
		
		return sessionFactory;
	}

}

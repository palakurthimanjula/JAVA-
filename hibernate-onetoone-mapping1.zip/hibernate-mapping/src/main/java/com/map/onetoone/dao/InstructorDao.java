package com.map.onetoone.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.map.onetoone.entity.Instructor;
import com.map.onetoone.utility.JavaConfig;

public class InstructorDao {
	
	
	public void saveInstructor(Instructor instructor)
	{
		Transaction transaction=null;
		
		try(Session session=JavaConfig.getSessionFactory().openSession() )
		{
			transaction=session.beginTransaction();
			session.save(instructor);
			
			transaction.commit();
		}
		catch(Exception e)
		{
			if(transaction!=null)
			transaction.rollback();
			
			System.out.println(e);
		}
	}
	
	
	
	public void updateInstructor(Instructor instructor)
	{
		Transaction transaction=null;
		
		try(Session session=JavaConfig.getSessionFactory().openSession() )
		{
			transaction=session.beginTransaction();
			
			
			session.update(instructor);
			
			transaction.commit();
		}
		catch(Exception e)
		{
			if(transaction!=null)
			transaction.rollback();
			
			System.out.println(e);
		}
	}
	
	
	public void deleteInstructor(long id)
	{
		Transaction transaction=null;
		
		try(Session session=JavaConfig.getSessionFactory().openSession() )
		{
			transaction=session.beginTransaction();
			
			
			Instructor instructor=session.get(Instructor.class, new Long(id));
			session.delete(instructor);
			
			transaction.commit();
		}
		catch(Exception e)
		{
			if(transaction!=null)
			transaction.rollback();
			
			System.out.println(e);
		}
	}
	
	
	public Instructor getInstructor(Long id)
	{
		Transaction transaction=null;
		Instructor instructor=null;
		try(Session session=JavaConfig.getSessionFactory().openSession() )
		{
			transaction=session.beginTransaction();
				
			instructor=session.get(Instructor.class, new Long(id));
		
			transaction.commit();
		}
		catch(Exception e)
		{
			if(transaction!=null)
			transaction.rollback();
			
			System.out.println(e);
		}
		return instructor;
	}

}

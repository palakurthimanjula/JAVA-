package com.map.onetoone;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.map.onetoone.dao.InstructorDao;
import com.map.onetoone.entity.Instructor;
import com.map.onetoone.entity.InstructorDetail;

public class App 
{
    public static void main( String[] args ) throws NumberFormatException, IOException
    {
    	
    	
    	BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(System.in));
    	System.out.println("===============================================");
    	System.out.println("\t 1 --> Insert");
    	System.out.println("\t 2 --> Update");
    	System.out.println("\t 3 --> Delete");
    	System.out.println("\t 4 --> Get");
    	System.out.println("===============================================");
    	System.out.println("Enter a choice:");
    	int choice=Integer.parseInt(bufferedReader.readLine());
    	System.out.println("===============================================");
    	InstructorDao dao=new InstructorDao();
    	switch(choice)
    	{
    		case 1 :   System.out.println("Enter Instructor Id:");
    				   long id=Long.parseLong(bufferedReader.readLine());
    				   System.out.println("Enter Instructor Details Id:");
    				   long insId=Long.parseLong(bufferedReader.readLine());
    				   System.out.println("First Name:");
    				   String firstName=bufferedReader.readLine();
    				   System.out.println("Last Name:");
    				   String lastName=bufferedReader.readLine();
    				   System.out.println("Email:");
    				   String email=bufferedReader.readLine();
    				   System.out.println("Hobby:");
    				   String hobby=bufferedReader.readLine();
    				   System.out.println("Youtube channel:");
    				   String youtube=bufferedReader.readLine();
    				   InstructorDetail instructorDetail=new InstructorDetail(insId, hobby, youtube);	
    			       Instructor instructor=new Instructor(id, firstName, lastName, email, instructorDetail);
    			       dao.saveInstructor(instructor);
    			       break;
    		case 2 :   System.out.println("Enter Instructor Id:");
					   id=Long.parseLong(bufferedReader.readLine());
					   
					   instructor=dao.getInstructor(id);	
					
					   if(instructor!=null)
					   {
						   instructorDetail=instructor.getInstructorDetail();
						   System.out.println("New First Name:");
						   firstName=bufferedReader.readLine();
						   System.out.println("New Last Name:");
						    lastName=bufferedReader.readLine();
						   System.out.println("Email:");
						    email=bufferedReader.readLine();
						   System.out.println("Hobby:");
						    hobby=bufferedReader.readLine();
						   System.out.println("Youtube channel:");
						    youtube=bufferedReader.readLine();
		   
						    instructorDetail.setHobby(hobby);
						   instructorDetail.setYoutubeChannel(youtube);
						   
						   instructor.setEmail(email);
						   instructor.setFirstName(firstName);
						   instructor.setLastName(lastName);
						   instructor.setInstructorDetail(instructorDetail);
					       dao.updateInstructor(instructor);
					   }
					   else
					   {
						    System.out.println("===============================================");
							System.out.println("Instructor Id does not exist!!");		
							System.out.println("===============================================");
					   }
				       break;       
    		case 3: System.out.println("Enter existing Instructor Id:");
    				id=Long.parseLong(bufferedReader.readLine());
    				dao.deleteInstructor(id);
    				break;
    		case 4:	System.out.println("Enter existing Instructor Id:");
					id=Long.parseLong(bufferedReader.readLine());	
					instructor=dao.getInstructor(id);
					System.out.println("===============================================");
					System.out.println("\t Id :"+instructor.getId()+"\t First Name:"+instructor.getFirstName()+"\t Last Name:"+instructor.getLastName()+ "\t Hobby:"+instructor.getInstructorDetail().getHobby());
					System.out.println("===============================================");
					break;
			default:System.out.println("===============================================");
					System.out.println("Wrong Input!!");		
					System.out.println("===============================================");

    	}
    	
    	
    	
       
      
    	
    }
}
